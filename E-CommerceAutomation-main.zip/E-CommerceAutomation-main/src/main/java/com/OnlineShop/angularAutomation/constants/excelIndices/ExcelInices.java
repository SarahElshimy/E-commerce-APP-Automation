package com.OnlineShop.angularAutomation.constants.excelIndices;

public class ExcelInices {
    public static final short TEST_CASE_ID_INDEX = 0;
    public static final short TEST_CASE_TITLE_INDEX = 1;
    public static final short TEST_SCOPE_INDEX = 2;
}
