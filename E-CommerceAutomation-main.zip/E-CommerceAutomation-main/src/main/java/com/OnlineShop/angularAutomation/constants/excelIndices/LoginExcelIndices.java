package com.OnlineShop.angularAutomation.constants.excelIndices;

public class LoginExcelIndices extends ExcelInices{
	
	public static final short USER_MAIL_INDEX = 3;
	public static final short USER_PASSWORD_INDEX = 4;
	public static final short ERR_TYPE_INDEX = 5;
	public static final short EXPECTED_RES_INDEX = 6;

}
