package com.OnlineShop.angularAutomation.constants.database;

public class DBTable {
    public static final String ID = "ID";
    public static final String NAME_EN = "NAME_EN";
    public static final String NAME_AR = "NAME_AR";
}
